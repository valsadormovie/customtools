#-------------------------------------------------
#-TILETOOLS_PANEL.py | CHATGPT - CONTEXT LITE EDIT
#-------------------------------------------------
from .global_settings import *

# ================== PANEL =================
class XTD_PT_TileTools(bpy.types.Panel):
    bl_label = "TILE TOOLS"
    bl_idname = "XTD_PT_tiletools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "XTD Tools"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def draw(self, context):
        layout = self.layout
        scene = bpy.context.scene
        tile_name = bpy.context.active_object.name
        
        row = layout.row(align=True)
        row.alignment = 'LEFT'
        box = layout.box()
        row = box.row(align=True)
        if bpy.context.active_object:
            tile_name = bpy.context.active_object.name
            row.label(text=f"Selected Object: {tile_name}", icon="OBJECT_DATA")
        else:
            row.label(text="No object selected!", icon="ERROR")
            return
            
        row.prop(bpy.context.scene, "xtd_tools_selectedobjectdata", text="OBJECT UUID DATA", emboss=False, icon_only=True, icon="TRIA_DOWN" if bpy.context.scene.xtd_tools_unvisiblemodif else "TRIA_RIGHT")
        if bpy.context.scene.xtd_tools_selectedobjectdata:
            box = layout.box()
            row = box.row(align=True)
            if "project_uuid" in bpy.context.active_object:
                grid = row.grid_flow(columns=1, align=True)
                uuid_data = UUIDManager.parse_project_uuid(bpy.context.active_object["project_uuid"])
                base_tile_name = uuid_data["uuid_base_tile_name"]
                base_tile_transfermode = uuid_data["uuid_transfermode"]
                base_tile_source = uuid_data["uuid_source_blendfile"]
                grid.label(text=f"TILE: {base_tile_name}", icon="ASSET_MANAGER")
                grid.label(text=f"TRANSFERMODE: {base_tile_transfermode}", icon="LINKED")
                grid.label(text=f"SOURCE: {base_tile_source}", icon="DECORATE_LIBRARY_OVERRIDE")
            else:
                row.label(text="Project UUID not found!", icon="ERROR")
        
        row.prop(scene, "xtd_tools_tiletools_mode", text="")

        mode_ui_elements = {
            "Append": {
                "label": "APPEND TILE OBJECT:",
                "icon": "APPEND_BLEND",
                "extra_props": [("xtd_tools_transferreplacemode", " REPLACE ")],
                "extra_text": "Choose a zoom level to be added",
            },
            "Link": {
                "label": "LINK TILE OBJECT:",
                "icon": "LINK_BLEND",
                "extra_props": [("xtd_tools_transferreplacemode", " REPLACE ")],
                "extra_text": "Choose a zoom level to be linked",
            },
            
        }

        mode_settings = mode_ui_elements.get(scene.xtd_tools_tiletools_mode, {})    
        
		layout = self.layout

		row = box.row(align=True)
		grid = row.grid_flow(columns=4, align=True)

		zoom_levels = ["BP18", "BP19", "BP20", "BP21"]
		operator_map = {
			"ShowAvailable": "xtd_tools.showavailable_tile_resolution",
			"Bake": "xtd_tools.bake_tile_resolution",
			"Append": "xtd_tools.append_tile_resolution",
			"Optimize": "xtd_tools.optimize_tile_resolution",
			"Link": "xtd_tools.link_tile_resolution"
		}
		operator_id = operator_map.get(scene.xtd_tools_tiletools_mode, "xtd_tools.showavailable_tile_resolution")

		for zoom_level in zoom_levels:
			exists, blendfile = self.check_resolution_availability(tile_name, zoom_level)
			sub_row = grid.row(align=True)
			sub_row.alert = not exists
			sub_row.enabled = exists
			op = sub_row.operator(operator_id, text=zoom_level)
			op.resolution = zoom_level

    def draw_accordion_box(self, context, layout, label, prop_name, column_span, buttons):
        scene = bpy.context.scene
        row = layout.row()  
        row.prop(scene, prop_name, text=label, emboss=False, icon_only=True, icon="TRIA_DOWN" if getattr(scene, prop_name) else "TRIA_RIGHT")
		if getattr(scene, prop_name):
			box = layout.box()
			row = box.row(align=True)
			row.prop(bpy.context.scene, "xtd_custom_collection_name")
			grid = box.grid_flow(columns=int(column_span), align=True)
			for button_text, operator, full_width in buttons:
				if full_width:
					grid.operator(f"xtd_tools.{operator}", text=button_text)
				else:
					grid.operator(f"xtd_tools.{operator}", text=button_text)


# ================ SCENES ================
bpy.types.Scene.xtd_tools_transferreplacemode = bpy.props.BoolProperty(name="Replace mode", default=False)
bpy.types.Scene.xtd_tools_tiletools_mode = bpy.props.EnumProperty(
    name="Tile Tools Mode",
    items=[
        ("Append", "Append", ""),
        ("Link", "Link", ""),
    ],
    default="Append"
)

# ================== Tile Append/Link Operators ==================
class XTD_OT_AppendTileResolution(global_settings.XTDToolsOperator):
    bl_idname = "xtd_tools.append_tile_resolution"
    bl_label = "Append tile resolution"
    bl_options = {'REGISTER', 'UNDO'}

    resolution: bpy.props.StringProperty()
    blend_file: bpy.props.StringProperty()

    def execute(self, context):
        global_settings.UUIDManager.ensure_project_uuid()
        global_settings.UUIDManager.deduplicate_project_uuids()
        transferreplacemode = bpy.context.scene.xtd_tools_transferreplacemode
        if transferreplacemode:
            selected_replace_mode = "REPLACE"
        else:
            selected_replace_mode = "ADD"
        return bpy.ops.xtd_tools.transfermodels(transfer_mode="APPEND", source_mode="MASTERFILE", objects="SELECTED", replace_mode=selected_replace_mode, zoom_level=self.resolution)
        
class XTD_OT_LinkTileResolution(global_settings.XTDToolsOperator):
    bl_idname = "xtd_tools.link_tile_resolution"
    bl_label = "Show Available Resolution"
    bl_options = {'REGISTER', 'UNDO'}

    resolution: bpy.props.StringProperty()
    blend_file: bpy.props.StringProperty()

    def execute(self, context):
        global_settings.UUIDManager.ensure_project_uuid()
        global_settings.UUIDManager.deduplicate_project_uuids()
        transferreplacemode = bpy.context.scene.xtd_tools_transferreplacemode
        if transferreplacemode:
            selected_replace_mode = "REPLACE"
        else:
            selected_replace_mode = "ADD"
        return bpy.ops.xtd_tools.transfermodels(transfer_mode="LINK", source_mode="MASTERFILE", objects="SELECTED", replace_mode=selected_replace_mode, zoom_level=self.resolution)
