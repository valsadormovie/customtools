#----------------------------------------------------------
#-GLOBAL_SETTINGS.py | CHATGPT - CONTEXT LITE EDIT
#----------------------------------------------------------
#  ================== IMPORTED LIBRARYS ================== 
import importlib
import inspect
import datetime
import random
import string
import bpy
import os
import time
import threading
import keyboard
import sys
from pathlib import Path
from bpy.props import EnumProperty, StringProperty, BoolProperty
from mathutils import Vector, Quaternion
from bpy import context

# ================== THIRDPARTY MODULE LIBRARYS ==================
import grapheme
import numpy as np
from alive_progress import alive_bar
from about_time import about_time
from colorist import hex, bg_hex, ColorHex, BgColorHex

# ================== REGISTERED PANEL TOOLS ==================
panels = [
    "global_settings",
    "tiletools_panel"
]

# ================== MAIN PANEL SCRIPTS ==================
panel_visibility = {panel: True for panel in panels}
registered_classes = []
global_functions = {}
registered_properties = []
global_settings = None

# ================== GLOBAL SETTINGS PANEL ==================
class XTD_GlobalSettingsPanel(bpy.types.Panel):
    bl_label = "GLOBAL SETTINGS"
    bl_idname = "XTD_PT_global_settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "XTD Tools"

    def draw(self, context):
        layout = self.layout
        scene = bpy.context.scene
        box = layout.box()
        row = box.row(align=True)
        row.label(text="BATCH PROCESS SETTINGS", icon="MOD_MULTIRES")
        row.prop(scene, "batch_mode", text="MODE")

# ================== GLOBAL EXECUTE OPERATOR ==================
class XTDToolsOperator(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}
    batch_mode = False
    _processed_objects = set()
    
    def execute(self, context):
        bl_label = self.bl_label
        self.__class__._processed_objects.clear()
        
        selected_objects = bpy.context.selected_objects
       
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}
        
        keyboard.add_hotkey("esc", ProcessManager.stop)
        ProcessManager.start()

        batch_size = int(bpy.context.scene.batch_mode)
        total_objects = len(selected_objects)
        total_batches = (total_objects + batch_size - 1) // batch_size

        start_time = time.time()

        for batch_index in range(total_batches):
            batch_objects = selected_objects[batch_index * batch_size: (batch_index + 1) * batch_size]
            if not ProcessManager.is_running():
                self.report({'INFO'}, "Process stopped by user.")
                return {'CANCELLED'}
            statusheader(bl_label, functiontext="Working selected objects...")
            if total_batches > 1: 
                print_status(batch_index + 1, total_batches, total_objects, batch_index * batch_size + len(batch_objects))
            with alive_bar(len(batch_objects), title='   ', enrich_print=True, enrich_offset=3, length=50, force_tty=True, max_cols=98, bar='filling') as bar:
                for obj in batch_objects:
                    if not ProcessManager.is_running():
                        self.report({'INFO'}, "Process stopped by user.")
                        return {'CANCELLED'}
                    self.process_object(obj)
                    self.__class__._processed_objects.add(obj.name)
                    bar()

        ProcessManager.reset()
        self.report({'INFO'}, "Process completed.")
        return {'FINISHED'}

    def process_object(self, obj):
        raise NotImplementedError("Subclasses must implement process_object method")

# ================== PROCESS MANAGER ==================
class ProcessManager:
    _is_running = True

    @classmethod
    def is_running(cls):
        return cls._is_running

    @classmethod
    def stop(cls):
        cls._is_running = False
        print("Folyamat leállítva.")
        bpy.context.preferences.edit.use_global_undo = True

    @classmethod
    def start(cls):
        cls._is_running = True

    @classmethod
    def reset(cls):
        cls._is_running = True
        bpy.context.preferences.edit.use_global_undo = True

# ================== UUIDManager ==================
class UUIDManager:
    @staticmethod
    def parse_project_uuid(project_uuid):
        if not project_uuid or "|" not in project_uuid:  # Ha üres vagy rossz formátumú
            return {
                "uuid_working_project": "",
                "uuid_base_tile_name": "",
                "uuid_source_blendfile": "",
                "uuid_transfertime": "",
                "uuid_transfermode": "",
                "uuid_unique_hash": ""
            }
        
        parts = project_uuid.split("|")
        return {
            "uuid_working_project": parts[0] if len(parts) > 0 else "",
            "uuid_base_tile_name": parts[1] if len(parts) > 1 else "",
            "uuid_source_blendfile": parts[2] if len(parts) > 2 else "",
            "uuid_transfertime": parts[3] if len(parts) > 3 else "",
            "uuid_transfermode": parts[4] if len(parts) > 4 else "",
            "uuid_unique_hash": parts[5] if len(parts) > 5 else ""
        }

    @staticmethod
    def generate_random_hash(length=8):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

    @staticmethod
    def ensure_project_uuid():
        project_filename = os.path.basename(bpy.data.filepath).replace(".blend", "")

        for obj in bpy.data.objects:
            if "project_uuid" not in obj or not obj["project_uuid"]:
                unique_id = f"{obj.name[:12]}|{project_filename}"
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                obj["project_uuid"] = f"{project_filename}|{unique_id}|{timestamp}|APPEND|{UUIDManager.generate_random_hash()}"

    @staticmethod
    def deduplicate_project_uuids():
        seen_uuids = {}
        
        for obj in bpy.data.objects:
            if not obj.get("project_uuid"):
                uuid_data = UUIDManager.parse_project_uuid(obj["project_uuid"])
                if uuid_data["uuid_transfermode"] != "LINK":
                    base_uuid = "|".join(obj["project_uuid"].split("|")[:-1])

                    if base_uuid in seen_uuids and obj["project_uuid"] == seen_uuids[base_uuid]:
                        obj["project_uuid"] = f"{base_uuid}|{UUIDManager.generate_random_hash()}"
                    else:
                        seen_uuids[base_uuid] = True

# ================== MAIN TRANSFER ENGINE ==================
class XTD_OT_TransferModels(XTDToolsOperator):
    bl_idname = "xtd_tools.transfermodels"
    bl_label = "Transfer Models"
    bl_description = "Transfer models between files"
    bl_options = {'REGISTER', 'UNDO'}

    transfer_mode: bpy.props.EnumProperty(
        items=[('APPEND', "Append", ""), ('LINK', "Link", "")],
        name="Transfer Mode",
        default='APPEND'
    )

    source_mode: bpy.props.EnumProperty(
        items=[('BLENDFILE', "Blend File", ""), ('MASTERFILE', "Master File", "")],
        name="Source Mode",
        default='MASTERFILE'
    )

    file_name: bpy.props.StringProperty(
        name="File Name",
        description="Specify the blend file name for BLENDFILENAME mode",
        default=""
    )

    node_group: bpy.props.StringProperty(
        name="Node Group",
        description="Specify node group",
        default=""
    )

    world: bpy.props.StringProperty(
        name="World",
        description="Specify world",
        default=""
    )

    objects: bpy.props.EnumProperty(
        items=[('SELECTED', "Selected", ""), ('ALL', "All", ""), ('OBJECTNAME', "Object Name", "")],
        name="Objects",
        default='SELECTED'
    )

    replace_mode: bpy.props.EnumProperty(
        items=[('ADD', "Add", ""), ('REPLACE', "Replace", "")],
        name="Replace Mode",
        default='ADD'
    )

    object_name: bpy.props.StringProperty(
        name="Object Name",
        description="Specify an object name for OBJECTNAME mode",
        default=""
    )
    
    zoom_level: bpy.props.StringProperty(
        name="Zoom level",
        description="Zoom level resolution",
        default=""
    )

    base_collection: bpy.props.EnumProperty(
        items=[('TEMP_LINKED', "Temp linked", ""), ('SCENE', "Scene", ""), ('COLLECTIONNAME', "Collectionname", "")],
        name="Collection transfer destination",
        default='TEMP_LINKED'
    )
    
    collection_name: bpy.props.StringProperty(
        name="Collection Name",
        description="Specify collection bane",
        default=""
    )

    def execute(self, context):
        if self.node_group.strip() != "" or self.world.strip() != "":
            result = self.process_utils(context, source_file)
            if 'CANCELLED' in result:
                return result
            self.report({'INFO'}, "Successfully linked node group.")
            return {'FINISHED'}
        else:
            selected_project_uuids = set()
            
            linked_objects = []
    
            if self.objects == 'SELECTED':
                try:
                    selected_objs = [o for o in bpy.context.selected_objects if "project_uuid" in o]

                    selected_base_tile_names = set()
                    for obj in selected_objs:
                        uuid_data = UUIDManager.parse_project_uuid(obj["project_uuid"])
                        if uuid_data and uuid_data["uuid_base_tile_name"]:
                            selected_base_tile_names.add(uuid_data["uuid_base_tile_name"])
                    
                    if self.replace_mode == 'REPLACE':
                        self.replace_existing_objects(selected_base_tile_names)
                    
                    selected_objs = [o for o in bpy.context.selected_objects if "project_uuid" in o]
                    linked_objects = []

                    for obj in selected_objs:
                        uuid_data = UUIDManager.parse_project_uuid(obj["project_uuid"])
                        if not uuid_data["uuid_base_tile_name"]:
                            continue
                        
                        source_file = self.get_source_file_for_object(obj)
                        if not source_file or not os.path.exists(source_file):
                            self.report({'WARNING'}, f"Source file for {obj.name} is invalid or missing.")
                            continue
                        
                        # Itt hívjuk a transfer_objects-t
                        one_uuid_set = {uuid_data["uuid_base_tile_name"]}
                        newly_linked = self.transfer_objects(source_file, one_uuid_set)
                        if newly_linked:
                            linked_objects.extend(newly_linked)

                    if not linked_objects:
                        self.report({'ERROR'}, "No objects were transferred.")
                        return {'CANCELLED'}
                        
                except ValueError:
                    return {'CANCELLED'}
            else:
                source_file = self.get_source_file(context)
                if not source_file or not os.path.exists(source_file):
                    self.report({'ERROR'}, "Blend file path is invalid or missing.")
                    return {'CANCELLED'}

                if self.objects == 'ALL':
                    selected_project_uuids = {"ALL"}
                elif self.objects == 'OBJECTNAME':
                    obj = bpy.data.objects.get(self.object_name)
                    if obj and "project_uuid" in obj:
                        uuid_data = UUIDManager.parse_project_uuid(obj.get("project_uuid", ""))
                        if uuid_data and uuid_data["uuid_base_tile_name"]:
                            selected_project_uuids = {uuid_data["uuid_base_tile_name"]}
                        else:
                            self.report({'ERROR'}, f"Object '{self.object_name}' does not have a valid project_uuid.")
                            return {'CANCELLED'}
                    else:
                        self.report({'ERROR'}, f"Object '{self.object_name}' not found.")
                        return {'CANCELLED'}
                else:
                    self.report({'ERROR'}, "Invalid objects mode selected.")
                    return {'CANCELLED'}

                if self.replace_mode == 'REPLACE':
                    self.replace_existing_objects(selected_project_uuids)

                linked_objects = self.transfer_objects(source_file, selected_project_uuids)
            
            if not linked_objects:
                self.report({'ERROR'}, "No objects were transferred.")
                return {'CANCELLED'}

            self.report({'INFO'}, f"Successfully transferred {len(linked_objects)} objects.")
            return {'FINISHED'}
        
        self.report({'INFO'}, "Transfer process completed.")
        return {'FINISHED'}

    def get_source_file_for_object(self, obj):
        master_folder = os.path.dirname(bpy.context.scene.master_txt_filepath)
        if self.source_mode == 'MASTERFILE':
            master_txt_filepath = bpy.context.scene.master_txt_filepath
            if not os.path.exists(master_txt_filepath):
                print(f"Master TXT file not found: {master_txt_filepath}")
                return None

            with open(master_txt_filepath, 'r') as file:
                lines = file.readlines()

            for line in lines:
                try:
                    name, blendfile, zoom = line.strip().split(" | ")
                    if name == obj.name[:12] and zoom == self.zoom_level:
                        return os.path.join(master_folder, blendfile)
                except ValueError:
                    continue
            return None

        elif self.source_mode == 'BLENDFILE':
            return os.path.join(master_folder, self.file_name)
        
        return None

    def get_source_file(self, context):
        def get_source_file(self, context):
            master_folder = os.path.dirname(bpy.context.scene.master_txt_filepath)
            if self.source_mode == 'MASTERFILE':
                return self.get_master_file(context)
            elif self.source_mode == 'BLENDFILE':
                return os.path.join(master_folder, self.file_name)
            return None
    
    def get_master_file(self, context):
        master_txt_filepath = bpy.context.scene.master_txt_filepath
        if not os.path.exists(master_txt_filepath):
            print(f"Master TXT file not found: {master_txt_filepath}")
            return None

        with open(master_txt_filepath, 'r') as file:
            lines = file.readlines()

        for line in lines:
            try:
                name, blendfile, zoom = line.strip().split(" | ")
                if name == obj.name[:12] and zoom == zoom_level:
                    return os.path.join(os.path.dirname(bpy.context.scene.master_txt_filepath), blendfile)
            except ValueError:
                continue 
        return None

    def process_utils(self, context, source_file):
        linked_utils = []
        
        node_group = bpy.data.node_groups.get(self.node_group)
        if self.node_group:
            node_group = bpy.data.node_groups.get(self.node_group)
            try:
                with bpy.data.libraries.load(source_file, link=(self.transfer_mode == 'LINK')) as (data_from, data_to):
                    if self.node_group in data_from.node_groups:
                        data_to.node_groups = [self.node_group]
                    else:
                        self.report({'ERROR'}, "Node group not found in source file.")
                        return {'CANCELLED'}
                return {'FINISHED'}
            except Exception as e:
                self.report({'ERROR'}, f"Error transferring node group: {e}")
                return {'CANCELLED'}
        
        worlds = bpy.data.worlds.get(self.world)
        if self.world:
            try:
                bpy.data.worlds.remove(self.world)
            except Exception as e:
                print(f"Error transfering node group: {e}") 
            try:
                world = self.world
                with bpy.data.libraries.load(source_file, link=(self.transfer_mode == 'LINK')) as (data_from, data_to):
                    if hasattr(data_from, "worlds"):
                        data_to.worlds = [world_name for world_name in data_from.worlds if world_name in bpy.data.worlds]
                if not data_to.worlds:
                    print("No world found to transfer.")
                    return None
        
                return None
            except Exception as e:
                print(f"Error transfering world: {e}")
            return {'FINISHED'}
            
        return linked_utils

    def get_util_names(self, context):
        node_group = bpy.data.node_groups.get(self.node_group)
        if self.node_group:
            return [node_group.name for node_group in bpy.data.node_groups]
        worlds = bpy.data.worlds.get(self.world)
        if self.world:
            return [world.name for world in bpy.data.worlds]
        return []

    def collectionchecker(self):
        if self.base_collection == "SCENE":
            return bpy.context.scene.collection
            
        if self.base_collection == "COLLECTIONNAME":
            if self.collection_name == "":
                collection_destination = f"Collection"
            else:
                collection_destination = f"{self.collection_name}"
        else:
            collection_destination = f"{self.base_collection}"
        
        temp_collection = bpy.data.collections.get(collection_destination)
        if not temp_collection:
            temp_collection = bpy.data.collections.new(collection_destination)
            bpy.context.scene.collection.children.link(temp_collection)
        return temp_collection

    def replace_existing_objects(self, selected_project_uuids):
        temp_collection = self.collectionchecker()
        
        if not temp_collection or not temp_collection.objects:
            return {'FINISHED'}
        
        objects_to_replace = []
        
        if temp_collection and temp_collection.objects:
            for obj in temp_collection.objects:
                if "project_uuid" in obj:
                    uuid_data = UUIDManager.parse_project_uuid(obj["project_uuid"])
                    if uuid_data and uuid_data["uuid_base_tile_name"] in selected_project_uuids:
                        objects_to_replace.append((obj, uuid_data))
        
        for obj, uuid_data in objects_to_replace:
            if uuid_data["uuid_transfermode"] == "APPEND":
                bpy.data.objects.remove(obj)
            elif uuid_data["uuid_transfermode"] == "LINK":
                temp_collection.objects.unlink(obj)
        
        return {'FINISHED'}


    def transfer_objects(self, source_file, selected_project_uuids):
        linked_objects = []
        try:
            with bpy.data.libraries.load(source_file, link=(self.transfer_mode == 'LINK')) as (data_from, data_to):
                if "ALL" in selected_project_uuids:
                    data_to.objects = list(data_from.objects)
                else:
                    data_to.objects = [
                        obj_name for obj_name in data_from.objects
                        if any(obj_name[:12] == uuid_base for uuid_base in selected_project_uuids)
                    ]
        
            if not hasattr(data_to, "objects") or not data_to.objects:
                print("No objects found to transfer.")
                return None
        
            temp_collection = self.collectionchecker()
            project_filename = os.path.basename(bpy.data.filepath).replace(".blend", "")
        
            for obj in data_to.objects:
                if obj and isinstance(obj, bpy.types.Object):
                    temp_collection.objects.link(obj)
                    linked_objects.append(obj)
        
                    unique_id = obj.get("unique_id", "NO_ID")
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    obj["project_uuid"] = f"{project_filename}|{unique_id}|{timestamp}|{self.transfer_mode}|{UUIDManager.generate_random_hash()}"
        
                    if obj.override_library is None and obj.library is not None:
                        obj.override_library_create(hierarchy=True)
                    obj.select_set(False)
        
        except Exception as e:
            return {'CANCELLED'}
        
        return linked_objects

# ================== DEFAULT GLOBAL PROPERTIES ==================
bpy.types.Scene.master_txt_filepath=  bpy.props.StringProperty(name="Master TXT Filepath",description="Path to the master TXT file",subtype='FILE_PATH',default=r"C:\Movie\BP\LINKEDPARTS\MASTER.txt")
bpy.types.Scene.xtd_tools_activepanels = bpy.props.BoolProperty(name="ACTIVE PANELS", default=False)
bpy.types.Scene.batch_mode = bpy.props.EnumProperty(
    name="BATCH SIZE",
    description="Control the batch process mode",
    items=[
        ('1', "DISABLED", ""),
        ('10', "10", ""),
        ('99999', "INFINITE", ""),
    ],
    default='1'
)

# ================== TIME AND STATUS ==================
class Timer:
    def __init__(self):
        self.start_time = time.time()

    def elapsed(self):
        return time.time() - self.start_time

def format_time(seconds):
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}"

def statusheader(bl_label, functiontext):
    os.system("cls")
    bg_hex(f"{bl_label}", "#161616")
    bg_hex(f"{functiontext}", "#161616")
    bg_hex(f"\n", "#161616")

def print_status(batch_index, total_batches, total_objects, current_index):
    bg_hex(f"BATCH READY: {batch_index} | TOTAL: {total_batches} | OBJECT READY: {current_index} | ALL OBJECTS: {total_objects}", "#161616")

# ================== HOTKEY SETUP ==================
def setup_hotkeys():
    keyboard.add_hotkey("esc", ProcessManager.stop)
